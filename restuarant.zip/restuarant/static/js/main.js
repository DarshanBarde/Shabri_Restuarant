function greet()
{
    alert("hello from greet function,js linked sucessfully")
}